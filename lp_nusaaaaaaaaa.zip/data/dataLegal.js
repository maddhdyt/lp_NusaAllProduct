// data/dataLegal.js

// 'export' membuat variabel ini bisa di-import oleh file lain.
export const testimonialsLegal = [
  {
    quote: "Urus Legalitas PT Saya Di Nusa Agency Cepat Banget, Nggak Sampai Seminggu Sudah Jadi. Semua Dijelaskan Dengan Detail, Dan Timnya Responsif Banget.",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    name: "Rizky Darmawan",
    title: "CEO Rumah Kreatif Bandung",
    rating: 5
  },
  {
    quote: "Prosesnya sangat mudah dan transparan. Tim Nusa Agency benar-benar profesional dan membantu saya dari awal sampai akhir. Sangat direkomendasikan!",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    name: "Amanda Sari",
    title: "Owner Kopi Senja",
    rating: 5
  },
  {
    quote: "Layanan terbaik! Saya tidak perlu pusing memikirkan birokrasi yang rumit. Semuanya diurus dengan cepat dan tuntas. Terima kasih Nusa Agency.",
    image: "https://randomuser.me/api/portraits/men/18.jpg",
    name: "Budi Santoso",
    title: "Founder Startup Logistik",
    rating: 5
  },
  {
    quote: "Layanan terbaik! Saya tidak perlu pusing memikirkan birokrasi yang rumit. Semuanya diurus dengan cepat dan tuntas. Terima kasih Nusa Agency.",
    image: "https://randomuser.me/api/portraits/men/18.jpg",
    name: "Budi Santoso",
    title: "Founder Startup Logistik",
    rating: 5
  },
  {
    quote: "Layanan terbaik! Saya tidak perlu pusing memikirkan birokrasi yang rumit. Semuanya diurus dengan cepat dan tuntas. Terima kasih Nusa Agency.",
    image: "https://randomuser.me/api/portraits/men/18.jpg",
    name: "Budi Santoso",
    title: "Founder Startup Logistik",
    rating: 5
  },
  {
    quote: "Layanan terbaik! Saya tidak perlu pusing memikirkan birokrasi yang rumit. Semuanya diurus dengan cepat dan tuntas. Terima kasih Nusa Agency.",
    image: "https://randomuser.me/api/portraits/men/18.jpg",
    name: "Budi Santoso",
    title: "Founder Startup Logistik",
    rating: 5
  },
  {
    quote: "Layanan terbaik! Saya tidak perlu pusing memikirkan birokrasi yang rumit. Semuanya diurus dengan cepat dan tuntas. Terima kasih Nusa Agency.",
    image: "https://randomuser.me/api/portraits/men/18.jpg",
    name: "Budi Santoso",
    title: "Founder Startup Logistik",
    rating: 5
  },
  // ... data lainnya
];